# Changelog

All notable changes to this project are documented in this file.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).
Versioning follows [Semantic Versioning](https://semver.org/).

---

## [2.0.0] — 2024-03-15

### Added — 15 new intelligence modules

- **`modules/web_archive.py`** — Wayback Machine timeline, snapshot content extraction, side-by-side snapshot diff via CDX API
- **`modules/github_recon.py`** — GitHub secret scanning with 30+ regex patterns (AWS keys, tokens, private keys, passwords), commit email harvesting, domain/org code exposure search
- **`modules/paste_monitor.py`** — Multi-source paste site search (Pastebin, Ghostbin, Gist, Rentry, Hastebin); auto-classification as credential dump, hash dump, or financial data
- **`modules/company_intel.py`** — OpenCorporates company search + officer lookup, SEC EDGAR filing search, LinkedIn job posting scraper with tech stack inference
- **`modules/threat_intel.py`** — AlienVault OTX pulse search, VirusTotal file/IP/domain/URL analysis, AbuseIPDB reporting, MalwareBazaar hash lookup, URLhaus URL check
- **`modules/email_header.py`** — Raw email header parser: hop chain reconstruction, SPF/DKIM/DMARC extraction, spoofing indicator detection, sender IP geolocation
- **`modules/reverse_image.py`** — Reverse image search URL generation for Google/Yandex/TinEye/Bing/Baidu, Tesseract + OCR.space fallback text extraction, image hashing (MD5/SHA1/SHA256)
- **`modules/crypto_tracer.py`** — Bitcoin address balance/transaction lookup via Blockchain.info, Ethereum via Etherscan, multi-chain via Blockchair, wallet risk flags, auto address type detection
- **`modules/dns_history.py`** — HackerTarget passive DNS (free), SecurityTrails historical records, ViewDNS IP history, reverse IP lookup
- **`modules/network_intel.py`** — BGPView ASN details + prefixes + peers + upstreams, IP-to-ASN resolution, org IP range search, RDAP registration lookup, quick TCP port check
- **`modules/cloud_discovery.py`** — S3/Azure Blob/GCS bucket enumeration with 30+ name permutations, Firebase Realtime Database exposure check
- **`modules/web_crawler.py`** — Recursive site spider with configurable depth and page limits, form extraction and classification, login/admin page detection, bulk email/phone harvest
- **`modules/ip_classifier.py`** — Tor exit node list (live from torproject.org), VPN/proxy/datacenter/residential detection via IPQualityScore + AbuseIPDB, bulk classification
- **`modules/graph_viz.py`** — Interactive D3.js entity-relationship graph (no pyvis required), auto-built from any OSINT result JSON, pyvis + NetworkX + GraphML export

### Changed

- `main.py` — Rewritten with 27 menu items + 27 CLI `--flags`; full investigation now auto-builds entity graph
- `config.py` — Added 8 new API key variables (GitHub, OTX, AbuseIPDB, SecurityTrails, Etherscan, IPQualityScore, TinEye, ViewDNS)
- `requirements.txt` — Added `pyvis`, `networkx`, `PyPDF2`, `python-docx`
- `.env.example` — Added all new API key variables

### Infrastructure

- Added `pyproject.toml` for proper Python packaging
- Added `CHANGELOG.md`
- Added `CODE_OF_CONDUCT.md`
- Added `.github/PULL_REQUEST_TEMPLATE.md`
- Added `.github/workflows/release.yml` — auto-creates GitHub Releases on version tags
- Updated `.github/workflows/ci.yml` — added Python 3.12, bandit security scan, black formatting check

---

## [1.0.0] — 2024-01-10

### Added — Initial release with 10 modules

- **`modules/username_lookup.py`** — Username enumeration across 30+ social platforms in parallel; email MX record lookup, Gravatar check, Hunter.io verification
- **`modules/domain_intel.py`** — WHOIS, full DNS (A/AAAA/MX/NS/TXT/SOA/CNAME), subdomain enumeration via crt.sh Certificate Transparency + DNS brute-force, SSL certificate analysis, Shodan host lookup, VirusTotal reputation, technology fingerprinting
- **`modules/phone_lookup.py`** — Phone number parsing with `phonenumbers`, carrier identification, line type detection, region geocoding; AbstractAPI + NumVerify enrichment
- **`modules/breach_check.py`** — HaveIBeenPwned v3 API email breach and paste lookup; password exposure check via k-anonymity (SHA-1 prefix only transmitted)
- **`modules/social_media.py`** — GitHub public API full profile scrape (repos, orgs, events, languages); Reddit user API; generic public page scraper with email/link extraction
- **`modules/metadata_extractor.py`** — EXIF data extraction from images including GPS coordinates with Google Maps link; PDF metadata (author, creator, producer); DOCX core properties; remote URL support
- **`modules/google_dorking.py`** — 15 dork templates (exposed files, config files, login pages, credentials, API keys, SSH keys, database dumps, subdomains, etc.); custom dork builder; DuckDuckGo execution; Google Custom Search API support
- **`modules/geolocation.py`** — IP geolocation via IPInfo + ip-api.com fallback; domain-to-IP-to-location; GPS reverse geocoding via Nominatim; forward geocoding; interactive Folium HTML map generation
- **`modules/monitoring.py`** — Target registration, SHA-256 based change detection, email alerts via SMTP, JSON alert file fallback, background threading scheduler
- **`utils/anonymity.py`** — Tor integration via `stem` library, proxy rotation, DNS leak detection, real vs Tor IP comparison
- **`reporting/report_generator.py`** — Dark-themed HTML report with full nested data rendering; JSON export; matplotlib breach exposure chart; platform presence pie chart
- `main.py` — Interactive numbered menu + full argparse CLI with `--flags` for every module
- `config.py` — Centralized configuration with python-dotenv

[2.0.0]: https://github.com/YOUR_USERNAME/osint-tool/releases/tag/v2.0.0
[1.0.0]: https://github.com/YOUR_USERNAME/osint-tool/releases/tag/v1.0.0
