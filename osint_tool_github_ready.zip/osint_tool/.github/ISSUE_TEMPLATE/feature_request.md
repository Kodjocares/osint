---
name: "✨ Feature / Module Request"
about: "Suggest a new module or enhancement"
title: "[FEAT] "
labels: ["enhancement"]
assignees: ""
---

## What Would You Like?

<!-- A clear description of the feature or new module you're proposing -->

## Problem It Solves

<!-- What OSINT gap does this fill? What use case does it enable? -->

## Proposed Implementation

<!-- How might this work? API, library, or scraping approach? -->

**Module name:** `modules/my_module.py`
**CLI flag:** `--my-flag <target>`
**Menu option:** `[28]`
**Free / requires API key:** Free / Requires key (sign-up URL)

## Example Output

```json
{
  "target": "example.com",
  "data": { }
}
```

## Alternatives Considered

<!-- Any existing tools or workarounds you've tried -->

## Additional Context

<!-- Links to API docs, similar tools, related issues -->
