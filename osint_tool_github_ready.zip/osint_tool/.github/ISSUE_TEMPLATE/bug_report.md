---
name: "🐛 Bug Report"
about: "Something isn't working as expected"
title: "[BUG] "
labels: ["bug", "triage"]
assignees: ""
---

## Description

<!-- A clear, concise description of the bug -->

## Steps to Reproduce

```bash
# Exact command used (redact any real targets)
python main.py --domain example.com
```

1.
2.
3.

## Expected Behaviour

<!-- What you expected to happen -->

## Actual Behaviour

<!-- What actually happened — include full traceback if available -->

```
Traceback (most recent call last):
  ...
```

## Environment

| Field | Value |
|-------|-------|
| OS | e.g. Ubuntu 22.04 / macOS 14.3 / Windows 11 |
| Python | e.g. 3.11.7 |
| Tool version | e.g. v2.0.0 or commit `abc1234` |
| Tor enabled | Yes / No |
| Relevant API keys configured | e.g. SHODAN=yes, VIRUSTOTAL=no |

## Log Output

<!-- Paste relevant lines from `output/osint_tool.log` — remove any sensitive data -->

```
```

## Additional Context

<!-- Screenshots, related issues, workarounds found, etc. -->
